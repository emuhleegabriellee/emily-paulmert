# After the Scroll website

Static landing page and privacy policy for After the Scroll, operated by Emily Paulmert.

## Publish on GitHub Pages
1. Create a NEW PUBLIC repository named `emily-paulmert` under the GitHub account `emuhleegabriellee`.
2. Upload the contents of this folder to the repository root, preserving the `privacy-policy/index.html` subfolder.
3. In the repository, go to Settings > Pages. Choose Deploy from a branch, branch `main`, folder `/ (root)`, then Save.
4. After deployment, visit `https://emuhleegabriellee.github.io/emily-paulmert/` and `https://emuhleegabriellee.github.io/emily-paulmert/privacy-policy/`.
5. Check that the privacy policy accurately reflects actual data processing and provide a usable privacy contact channel before submitting to Pinterest.

The existing private bot repository should remain private.
